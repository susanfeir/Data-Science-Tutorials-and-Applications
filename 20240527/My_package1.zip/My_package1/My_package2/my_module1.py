def myfunc():
    print("Hello! My Package! My Module")